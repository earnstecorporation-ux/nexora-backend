const crypto = require('crypto');
const assert = require('assert');

// Test HMAC-SHA256 signature verification formula
const testKeySecret = 'test_secret_123456';
const testOrderId = 'order_test_12345';
const testPaymentId = 'pay_test_67890';

const text = `${testOrderId}|${testPaymentId}`;
const validSignature = crypto
  .createHmac('sha256', testKeySecret)
  .update(text)
  .digest('hex');

// Timing-safe check
const computedSignature = crypto
  .createHmac('sha256', testKeySecret)
  .update(text)
  .digest('hex');

const isAuthentic = crypto.timingSafeEqual(
  Buffer.from(computedSignature, 'utf-8'),
  Buffer.from(validSignature, 'utf-8')
);

assert.strictEqual(isAuthentic, true, 'HMAC signature verification must match');

const invalidSignature = 'invalid_tampered_signature_hex';
let isTamperedAuthentic = false;
try {
  isTamperedAuthentic = crypto.timingSafeEqual(
    Buffer.from(computedSignature, 'utf-8'),
    Buffer.from(invalidSignature, 'utf-8')
  );
} catch (e) {
  isTamperedAuthentic = false;
}

assert.strictEqual(isTamperedAuthentic, false, 'Tampered signature must fail verification');

console.log('✅ Backend HMAC SHA-256 signature test passed successfully.');
