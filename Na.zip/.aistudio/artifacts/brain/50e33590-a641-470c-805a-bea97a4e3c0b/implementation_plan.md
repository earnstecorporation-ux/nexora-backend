# Implementation Plan: Resolving Phone Auth in AI Studio Preview

The error "App verification failed — a valid Activity is required" confirms that the native Firebase Phone Auth SDK is attempting to trigger a `SafetyNet` / `Play Integrity` reCAPTCHA check, which the AI Studio streamed emulator cannot perform because it lacks the necessary system-level integration.

Even with "Test phone numbers" configured in Firebase, the native Android SDK often attempts to trigger the integrity check *before* verifying the phone number against the test list.

### Plan
To support testing in the AI Studio browser preview without changing your native Android codebase, I will implement a **Debug Auth Bypass** that is strictly limited to the `debug` build variant.

1.  **Modify `AuthRepository.kt`**: Add a check for a `BuildConfig.DEBUG` flag. If enabled, the `sendOtp` and `verifyOtp` methods will bypass actual Firebase network calls and simulate a successful authentication, allowing you to proceed to the main app functionality within the preview.
2.  **Ensure Safety**:
    *   This bypass will *only* be active in `debug` builds.
    *   The `release` build (used for final APKs) will remain unchanged and fully secure, using the production Firebase SDK.
3.  **No Structural Changes**: I will not attempt to rewrite the app to use Web SDKs (which is technically impossible in a native Kotlin/Compose project).

### Security & Compliance
*   **Zero Leakage**: No production API keys or secrets will be exposed.
*   **Production Safety**: The logic will be wrapped in `if (BuildConfig.DEBUG)`.
*   **Authentication**: Real authentication will remain required for the `release` build.

### Next Steps
1.  I will write the modified `AuthRepository.kt` to include the `BuildConfig.DEBUG` bypass.
2.  I will verify this fix by ensuring the app proceeds when using a test phone number in the preview.

Do you approve this approach for enabling testing in the preview environment?
