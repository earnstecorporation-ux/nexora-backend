package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.payment.model.CreateOrderResponse
import com.example.data.payment.model.VerifySignatureResponse
import com.example.data.payment.repository.PremiumEntitlementManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PaymentEntitlementUnitTest {

    private lateinit var context: Context
    private lateinit var entitlementManager: PremiumEntitlementManager
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        entitlementManager = PremiumEntitlementManager(context)
        entitlementManager.resetForTesting()
    }

    @Test
    fun testDefaultEntitlementIsFree() {
        assertFalse("Default entitlement must be free tier", entitlementManager.isPremium)
        assertEquals("", entitlementManager.entitlement.value.orderId)
        assertNull("Pending verification must initially be null", entitlementManager.pendingVerification.value)
    }

    @Test
    fun testSaveVerifiedEntitlementPersists() {
        val testOrderId = "order_test_12345"
        val testPaymentId = "pay_test_67890"
        val testToken = "token_sig_abc"
        val timestamp = 1713300000000L

        entitlementManager.saveVerifiedEntitlement(
            orderId = testOrderId,
            paymentId = testPaymentId,
            token = testToken,
            verifiedAt = timestamp
        )

        assertTrue("User must be marked as Premium after verification", entitlementManager.isPremium)
        assertEquals(testOrderId, entitlementManager.entitlement.value.orderId)
        assertEquals(testPaymentId, entitlementManager.entitlement.value.paymentId)
        assertEquals(testToken, entitlementManager.entitlement.value.token)
        assertEquals(timestamp, entitlementManager.entitlement.value.verifiedAt)

        // New manager instance on same context should restore persisted values
        val newManager = PremiumEntitlementManager(context)
        assertTrue("Persisted entitlement must survive app restart", newManager.isPremium)
        assertEquals(testOrderId, newManager.entitlement.value.orderId)
    }

    @Test
    fun testPendingVerificationLifecycle() {
        entitlementManager.savePendingVerification(
            orderId = "order_pending_11",
            paymentId = "pay_pending_22",
            signature = "sig_pending_33"
        )

        val pending = entitlementManager.pendingVerification.value
        assertNotNull(pending)
        assertEquals("order_pending_11", pending?.orderId)
        assertEquals("pay_pending_22", pending?.paymentId)
        assertEquals("sig_pending_33", pending?.signature)
        assertFalse("Pending payment must NOT unlock premium until verified", entitlementManager.isPremium)

        // Verifying entitlement clears pending
        entitlementManager.saveVerifiedEntitlement("order_pending_11", "pay_pending_22", "token_verified")
        assertNull(entitlementManager.pendingVerification.value)
        assertTrue(entitlementManager.isPremium)
    }

    @Test
    fun testResetForTesting() {
        entitlementManager.saveVerifiedEntitlement("order_xyz", "pay_xyz", "tok_xyz")
        assertTrue(entitlementManager.isPremium)

        entitlementManager.resetForTesting()
        assertFalse(entitlementManager.isPremium)
        assertEquals("", entitlementManager.entitlement.value.orderId)
    }

    @Test
    fun testVerifySignatureJsonSerialization() {
        val adapter = moshi.adapter(VerifySignatureResponse::class.java)
        val json = """
            {
                "verified": true,
                "status": "PAID",
                "orderId": "order_EKwxwAgItmmXdp",
                "paymentId": "pay_29QQoUBi66xm2f",
                "amount": 4900,
                "currency": "INR",
                "entitlement": "LIFETIME_PREMIUM",
                "entitlementToken": "token_proof_abc",
                "verifiedAt": 1713333333333,
                "message": "Payment signature verified successfully"
            }
        """.trimIndent()

        val response = adapter.fromJson(json)
        assertNotNull(response)
        assertTrue(response!!.verified)
        assertEquals("order_EKwxwAgItmmXdp", response.orderId)
        assertEquals("pay_29QQoUBi66xm2f", response.paymentId)
        assertEquals(4900L, response.amount)
        assertEquals("INR", response.currency)
    }

    @Test
    fun testCreateOrderJsonResponseParsing() {
        val adapter = moshi.adapter(CreateOrderResponse::class.java)
        val json = """
            {
                "success": true,
                "orderId": "order_778899",
                "amount": 4900,
                "currency": "INR",
                "keyId": "rzp_test_51gW4s8O4Qe8k7"
            }
        """.trimIndent()

        val response = adapter.fromJson(json)
        assertNotNull(response)
        assertTrue(response!!.success)
        assertEquals("order_778899", response.orderId)
        assertEquals(4900L, response.amount)
        assertEquals("rzp_test_51gW4s8O4Qe8k7", response.keyId)
    }

    @Test
    fun testValidateBackendUrlRejectsSecretsAndEmpty() {
        val repo = com.example.data.payment.repository.PaymentRepository(
            entitlementManager = entitlementManager,
            defaultBackendUrl = "https://placeholder.test",
            defaultRazorpayKeyId = "rzp_test_123"
        )

        // Empty URL
        val (emptyValid, emptyMsg) = repo.validateAndNormalizeUrl("")
        assertFalse(emptyValid)
        assertTrue(emptyMsg.contains("Backend URL is not configured"))

        // Razorpay Secret mistakenly entered as backend URL
        val (secretValid, secretMsg) = repo.validateAndNormalizeUrl("Oo4rRsY8TMMrHAmITIea9SGH")
        assertFalse(secretValid)
        assertTrue(secretMsg.contains("API Key or Secret"))

        // Razorpay Key ID mistakenly entered as backend URL
        val (keyValid, keyMsg) = repo.validateAndNormalizeUrl("rzp_live_SPydrdE58WgdWL")
        assertFalse(keyValid)
        assertTrue(keyMsg.contains("API Key or Secret"))

        // Auto-prepend https:// when user enters bare domain
        val (domainValid, domainUrl) = repo.validateAndNormalizeUrl("nexora-payments.onrender.com")
        assertTrue(domainValid)
        assertEquals("https://nexora-payments.onrender.com/", domainUrl)

        // Valid https URL
        val (httpsValid, httpsUrl) = repo.validateAndNormalizeUrl("https://api.example.com/payment")
        assertTrue(httpsValid)
        assertEquals("https://api.example.com/payment/", httpsUrl)
    }
}
