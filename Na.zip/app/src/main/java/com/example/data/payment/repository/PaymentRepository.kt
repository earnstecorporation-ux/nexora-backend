package com.example.data.payment.repository

import com.example.data.payment.model.CreateOrderRequest
import com.example.data.payment.model.CreateOrderResponse
import com.example.data.payment.model.HealthResponse
import com.example.data.payment.model.VerifySignatureRequest
import com.example.data.payment.model.VerifySignatureResponse
import com.example.data.payment.network.PaymentApiService
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class PaymentRepository(
    private val entitlementManager: PremiumEntitlementManager,
    private val defaultBackendUrl: String,
    private val defaultRazorpayKeyId: String
) {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    /**
     * Validates and normalizes candidate backend URL.
     * Prevents OkHttp "Expected URL scheme 'http' or 'https'" crash when URL is empty,
     * malformed, or when a user mistakenly enters a Razorpay API key/secret.
     *
     * @return Pair(isValid, normalizedUrlOrErrorMessage)
     */
    fun validateAndNormalizeUrl(rawUrl: String): Pair<Boolean, String> {
        val trimmed = rawUrl.trim()

        if (trimmed.isEmpty()) {
            return Pair(
                false,
                "Backend URL is not configured. Please deploy the backend in /backend and set a valid HTTPS URL (e.g. https://your-backend.onrender.com)."
            )
        }

        // Detect if the user mistakenly pasted a Razorpay Key ID or Key Secret
        val isLikelyKeyOrSecret = trimmed.startsWith("rzp_", ignoreCase = true) ||
                (!trimmed.contains("://") && !trimmed.contains(".") && trimmed.length >= 16)

        if (isLikelyKeyOrSecret) {
            return Pair(
                false,
                "The configured Backend URL appears to be an API Key or Secret, not a server URL.\n" +
                "For security, your Razorpay Key Secret must NEVER be placed in the Android app—it belongs exclusively on your backend.\n" +
                "Please deploy your backend service and enter its public HTTPS URL (e.g., https://your-backend.onrender.com)."
            )
        }

        // Auto-prefix https:// if user entered domain without protocol (e.g. "my-app.onrender.com")
        val withScheme = if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            "https://$trimmed"
        } else {
            trimmed
        }

        val normalized = if (withScheme.endsWith("/")) withScheme else "$withScheme/"

        // Verify valid URL via java.net.URI before passing to Retrofit
        val isValid = try {
            val uri = java.net.URI(normalized)
            (uri.scheme?.equals("http", ignoreCase = true) == true || uri.scheme?.equals("https", ignoreCase = true) == true) &&
                    !uri.host.isNullOrBlank()
        } catch (e: Exception) {
            false
        }

        return if (isValid) {
            Pair(true, normalized)
        } else {
            Pair(
                false,
                "Invalid Backend URL: '$rawUrl'. Expected a valid address starting with http:// or https:// (e.g. https://your-backend.onrender.com)."
            )
        }
    }

    private fun getApiServiceForUrl(validBaseUrl: String): PaymentApiService {
        val retrofit = Retrofit.Builder()
            .baseUrl(validBaseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        return retrofit.create(PaymentApiService::class.java)
    }

    fun getEffectiveBackendUrl(): String {
        return entitlementManager.getBackendUrl(defaultBackendUrl)
    }

    fun setEffectiveBackendUrl(url: String) {
        entitlementManager.setBackendUrl(url)
    }

    fun getEffectiveRazorpayKeyId(): String {
        return entitlementManager.getRazorpayKeyId(defaultRazorpayKeyId)
    }

    fun setEffectiveRazorpayKeyId(keyId: String) {
        entitlementManager.setRazorpayKeyId(keyId)
    }

    /**
     * Tests connectivity to a given candidate backend URL without committing it.
     */
    suspend fun testBackendConnection(candidateUrl: String): Result<HealthResponse> = withContext(Dispatchers.IO) {
        val (isValid, normalizedUrlOrError) = validateAndNormalizeUrl(candidateUrl)
        if (!isValid) {
            return@withContext Result.failure(IllegalArgumentException(normalizedUrlOrError))
        }

        try {
            val api = getApiServiceForUrl(normalizedUrlOrError)
            val response = api.checkHealth()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Backend health check failed: HTTP ${response.code()} ${response.message()}"))
            }
        } catch (e: ConnectException) {
            Result.failure(ConnectException("Connection refused at $normalizedUrlOrError. The backend server is not running or unreachable."))
        } catch (e: UnknownHostException) {
            Result.failure(UnknownHostException("Cannot reach domain at $normalizedUrlOrError (Host not found). Please verify your deployed backend HTTPS URL."))
        } catch (e: SocketTimeoutException) {
            Result.failure(SocketTimeoutException("Connection timed out reaching $normalizedUrlOrError. Please check your backend service status."))
        } catch (e: Exception) {
            Result.failure(Exception(e.localizedMessage ?: "Failed to connect to backend server at $normalizedUrlOrError"))
        }
    }

    /**
     * Checks if current effective backend server is online and operational
     */
    suspend fun checkBackendHealth(): Result<HealthResponse> = withContext(Dispatchers.IO) {
        testBackendConnection(getEffectiveBackendUrl())
    }

    /**
     * Creates order on the secure backend server for ₹49.
     * Prevents raw OkHttp crash and provides actionable failure descriptions.
     */
    suspend fun createOrder(receipt: String): Result<CreateOrderResponse> = withContext(Dispatchers.IO) {
        val (isValid, normalizedUrlOrError) = validateAndNormalizeUrl(getEffectiveBackendUrl())
        if (!isValid) {
            return@withContext Result.failure(IllegalArgumentException(normalizedUrlOrError))
        }

        try {
            val api = getApiServiceForUrl(normalizedUrlOrError)
            val response = api.createOrder(CreateOrderRequest(receipt))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success && body.orderId.isNotBlank()) {
                    Result.success(body)
                } else {
                    Result.failure(Exception(body.error ?: "Backend server failed to generate Razorpay order ID."))
                }
            } else {
                val errorBody = response.errorBody()?.string() ?: response.message()
                Result.failure(Exception("Backend returned HTTP ${response.code()}: $errorBody"))
            }
        } catch (e: ConnectException) {
            Result.failure(ConnectException("Cannot connect to payment backend at $normalizedUrlOrError (Connection refused). Is the backend server running?"))
        } catch (e: UnknownHostException) {
            Result.failure(UnknownHostException("Cannot reach backend host at $normalizedUrlOrError (DNS host not found). Please check your backend URL."))
        } catch (e: SocketTimeoutException) {
            Result.failure(SocketTimeoutException("Payment backend timed out at $normalizedUrlOrError. Please verify your backend server."))
        } catch (e: Exception) {
            Result.failure(Exception(e.localizedMessage ?: "Failed to connect to payment backend at $normalizedUrlOrError"))
        }
    }

    /**
     * Sends Razorpay payment output to backend for HMAC SHA-256 signature verification.
     * Premium is unlocked ONLY if verification succeeds!
     */
    suspend fun verifyPayment(
        orderId: String,
        paymentId: String,
        signature: String
    ): Result<VerifySignatureResponse> = withContext(Dispatchers.IO) {
        val (isValid, normalizedUrlOrError) = validateAndNormalizeUrl(getEffectiveBackendUrl())
        if (!isValid) {
            entitlementManager.savePendingVerification(orderId, paymentId, signature)
            return@withContext Result.failure(IllegalArgumentException(normalizedUrlOrError))
        }

        try {
            val api = getApiServiceForUrl(normalizedUrlOrError)
            val response = api.verifySignature(
                VerifySignatureRequest(
                    orderId = orderId,
                    paymentId = paymentId,
                    signature = signature
                )
            )

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.verified) {
                    // Cryptographically verified by server!
                    entitlementManager.saveVerifiedEntitlement(
                        orderId = orderId,
                        paymentId = paymentId,
                        token = body.entitlementToken,
                        verifiedAt = if (body.verifiedAt > 0) body.verifiedAt else System.currentTimeMillis()
                    )
                    Result.success(body)
                } else {
                    // Signature check failed on server
                    Result.failure(Exception(body.error ?: "Payment signature verification rejected by backend. Entitlement denied."))
                }
            } else {
                // Server error / temporary issue: save pending verification so user can retry anytime
                entitlementManager.savePendingVerification(orderId, paymentId, signature)
                val errorBody = response.errorBody()?.string() ?: response.message()
                Result.failure(Exception("Verification server error (HTTP ${response.code()}): $errorBody. Payment record saved; tap Retry Verification."))
            }
        } catch (e: Exception) {
            // Network failure during verification: save pending verification so user does not lose payment
            entitlementManager.savePendingVerification(orderId, paymentId, signature)
            Result.failure(Exception("Network error contacting verification backend: ${e.localizedMessage}. Payment record saved; tap Retry Verification once server is reachable."))
        }
    }

    /**
     * Retries signature verification for an unpaid or pending payment that was saved
     */
    suspend fun retryPendingVerification(): Result<VerifySignatureResponse> = withContext(Dispatchers.IO) {
        val pending = entitlementManager.pendingVerification.value
            ?: return@withContext Result.failure(Exception("No pending payment verification found."))

        verifyPayment(
            orderId = pending.orderId,
            paymentId = pending.paymentId,
            signature = pending.signature
        )
    }
}
