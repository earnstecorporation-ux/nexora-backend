package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recent_operations")
data class RecentOperation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val toolType: String, // "PDF", "RESIZE", "COMPRESS", "SCAN"
    val filePath: String,
    val fileUri: String = "",
    val originalSizeBytes: Long,
    val outputSizeBytes: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String = ""
)
