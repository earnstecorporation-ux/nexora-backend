package com.example.data.repository

import com.example.data.db.OperationDao
import com.example.data.db.RecentOperation
import kotlinx.coroutines.flow.Flow
import java.io.File

class HistoryRepository(private val operationDao: OperationDao) {

    val allOperations: Flow<List<RecentOperation>> = operationDao.getAllOperations()
    val recentOperations: Flow<List<RecentOperation>> = operationDao.getRecentOperations()

    suspend fun recordOperation(
        title: String,
        toolType: String,
        filePath: String,
        fileUri: String,
        originalSizeBytes: Long,
        outputSizeBytes: Long,
        details: String
    ): Long {
        val op = RecentOperation(
            title = title,
            toolType = toolType,
            filePath = filePath,
            fileUri = fileUri,
            originalSizeBytes = originalSizeBytes,
            outputSizeBytes = outputSizeBytes,
            timestamp = System.currentTimeMillis(),
            details = details
        )
        return operationDao.insertOperation(op)
    }

    suspend fun deleteOperation(operation: RecentOperation) {
        // Also remove cached file if exists
        try {
            val file = File(operation.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {}
        operationDao.deleteOperation(operation)
    }

    suspend fun clearHistory() {
        operationDao.clearAll()
    }
}
