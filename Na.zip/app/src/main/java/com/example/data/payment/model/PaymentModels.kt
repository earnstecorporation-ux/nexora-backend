package com.example.data.payment.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CreateOrderRequest(
    @param:Json(name = "receipt") val receipt: String = ""
)

@JsonClass(generateAdapter = true)
data class CreateOrderResponse(
    @param:Json(name = "success") val success: Boolean = true,
    @param:Json(name = "orderId") val orderId: String = "",
    @param:Json(name = "amount") val amount: Long = 4900,
    @param:Json(name = "currency") val currency: String = "INR",
    @param:Json(name = "keyId") val keyId: String = "",
    @param:Json(name = "receipt") val receipt: String = "",
    @param:Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class VerifySignatureRequest(
    @param:Json(name = "orderId") val orderId: String,
    @param:Json(name = "paymentId") val paymentId: String,
    @param:Json(name = "signature") val signature: String
)

@JsonClass(generateAdapter = true)
data class VerifySignatureResponse(
    @param:Json(name = "verified") val verified: Boolean = false,
    @param:Json(name = "status") val status: String = "",
    @param:Json(name = "orderId") val orderId: String = "",
    @param:Json(name = "paymentId") val paymentId: String = "",
    @param:Json(name = "amount") val amount: Long = 0,
    @param:Json(name = "currency") val currency: String = "INR",
    @param:Json(name = "entitlement") val entitlement: String = "",
    @param:Json(name = "entitlementToken") val entitlementToken: String = "",
    @param:Json(name = "verifiedAt") val verifiedAt: Long = 0,
    @param:Json(name = "message") val message: String = "",
    @param:Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @param:Json(name = "status") val status: String = "",
    @param:Json(name = "service") val service: String = "",
    @param:Json(name = "mode") val mode: String = "",
    @param:Json(name = "keyConfigured") val keyConfigured: Boolean = false,
    @param:Json(name = "timestamp") val timestamp: String = ""
)
