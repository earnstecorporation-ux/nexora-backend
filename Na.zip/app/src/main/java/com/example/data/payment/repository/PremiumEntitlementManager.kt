package com.example.data.payment.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VerifiedEntitlement(
    val isPremium: Boolean = false,
    val orderId: String = "",
    val paymentId: String = "",
    val verifiedAt: Long = 0L,
    val token: String = ""
)

data class PendingVerification(
    val orderId: String,
    val paymentId: String,
    val signature: String,
    val timestamp: Long
)

class PremiumEntitlementManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME, Context.MODE_PRIVATE
    )

    private val _entitlement = MutableStateFlow(loadEntitlement())
    val entitlement: StateFlow<VerifiedEntitlement> = _entitlement.asStateFlow()

    private val _pendingVerification = MutableStateFlow(loadPendingVerification())
    val pendingVerification: StateFlow<PendingVerification?> = _pendingVerification.asStateFlow()

    val isPremium: Boolean
        get() = _entitlement.value.isPremium

    private fun loadEntitlement(): VerifiedEntitlement {
        val isPrem = prefs.getBoolean(KEY_IS_PREMIUM, false)
        val orderId = prefs.getString(KEY_VERIFIED_ORDER_ID, "") ?: ""
        val paymentId = prefs.getString(KEY_VERIFIED_PAYMENT_ID, "") ?: ""
        val verifiedAt = prefs.getLong(KEY_VERIFIED_AT, 0L)
        val token = prefs.getString(KEY_ENTITLEMENT_TOKEN, "") ?: ""
        return VerifiedEntitlement(
            isPremium = isPrem,
            orderId = orderId,
            paymentId = paymentId,
            verifiedAt = verifiedAt,
            token = token
        )
    }

    private fun loadPendingVerification(): PendingVerification? {
        val orderId = prefs.getString(KEY_PENDING_ORDER_ID, null) ?: return null
        val paymentId = prefs.getString(KEY_PENDING_PAYMENT_ID, null) ?: return null
        val signature = prefs.getString(KEY_PENDING_SIGNATURE, null) ?: return null
        val timestamp = prefs.getLong(KEY_PENDING_TIMESTAMP, 0L)
        return PendingVerification(orderId, paymentId, signature, timestamp)
    }

    /**
     * Persists trusted, backend-verified payment entitlement
     */
    fun saveVerifiedEntitlement(
        orderId: String,
        paymentId: String,
        token: String,
        verifiedAt: Long = System.currentTimeMillis()
    ) {
        prefs.edit()
            .putBoolean(KEY_IS_PREMIUM, true)
            .putString(KEY_VERIFIED_ORDER_ID, orderId)
            .putString(KEY_VERIFIED_PAYMENT_ID, paymentId)
            .putString(KEY_ENTITLEMENT_TOKEN, token)
            .putLong(KEY_VERIFIED_AT, verifiedAt)
            // Clear pending once verified
            .remove(KEY_PENDING_ORDER_ID)
            .remove(KEY_PENDING_PAYMENT_ID)
            .remove(KEY_PENDING_SIGNATURE)
            .remove(KEY_PENDING_TIMESTAMP)
            .apply()

        _entitlement.value = VerifiedEntitlement(
            isPremium = true,
            orderId = orderId,
            paymentId = paymentId,
            verifiedAt = verifiedAt,
            token = token
        )
        _pendingVerification.value = null
    }

    /**
     * Persists pending verification data so user doesn't lose payment record if offline
     */
    fun savePendingVerification(
        orderId: String,
        paymentId: String,
        signature: String
    ) {
        val now = System.currentTimeMillis()
        prefs.edit()
            .putString(KEY_PENDING_ORDER_ID, orderId)
            .putString(KEY_PENDING_PAYMENT_ID, paymentId)
            .putString(KEY_PENDING_SIGNATURE, signature)
            .putLong(KEY_PENDING_TIMESTAMP, now)
            .apply()

        _pendingVerification.value = PendingVerification(orderId, paymentId, signature, now)
    }

    fun clearPendingVerification() {
        prefs.edit()
            .remove(KEY_PENDING_ORDER_ID)
            .remove(KEY_PENDING_PAYMENT_ID)
            .remove(KEY_PENDING_SIGNATURE)
            .remove(KEY_PENDING_TIMESTAMP)
            .apply()
        _pendingVerification.value = null
    }

    fun getBackendUrl(defaultUrl: String): String {
        return prefs.getString(KEY_CUSTOM_BACKEND_URL, null) ?: defaultUrl
    }

    fun setBackendUrl(url: String) {
        prefs.edit().putString(KEY_CUSTOM_BACKEND_URL, url.trim()).apply()
    }

    fun getRazorpayKeyId(defaultKey: String): String {
        return prefs.getString(KEY_CUSTOM_RAZORPAY_KEY, null) ?: defaultKey
    }

    fun setRazorpayKeyId(keyId: String) {
        prefs.edit().putString(KEY_CUSTOM_RAZORPAY_KEY, keyId.trim()).apply()
    }

    /**
     * Reset entitlement - useful for testing or staging verification
     */
    fun resetForTesting() {
        prefs.edit().clear().apply()
        _entitlement.value = VerifiedEntitlement()
        _pendingVerification.value = null
    }

    companion object {
        private const val PREFS_NAME = "nexora_entitlements"
        private const val KEY_IS_PREMIUM = "is_lifetime_premium"
        private const val KEY_VERIFIED_ORDER_ID = "verified_order_id"
        private const val KEY_VERIFIED_PAYMENT_ID = "verified_payment_id"
        private const val KEY_ENTITLEMENT_TOKEN = "entitlement_token"
        private const val KEY_VERIFIED_AT = "verified_at"

        private const val KEY_PENDING_ORDER_ID = "pending_order_id"
        private const val KEY_PENDING_PAYMENT_ID = "pending_payment_id"
        private const val KEY_PENDING_SIGNATURE = "pending_signature"
        private const val KEY_PENDING_TIMESTAMP = "pending_timestamp"

        private const val KEY_CUSTOM_BACKEND_URL = "custom_backend_url"
        private const val KEY_CUSTOM_RAZORPAY_KEY = "custom_razorpay_key"
    }
}
