package com.example.data.payment.network

import com.example.data.payment.model.CreateOrderRequest
import com.example.data.payment.model.CreateOrderResponse
import com.example.data.payment.model.HealthResponse
import com.example.data.payment.model.VerifySignatureRequest
import com.example.data.payment.model.VerifySignatureResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface PaymentApiService {

    @GET("api/health")
    suspend fun checkHealth(): Response<HealthResponse>

    @POST("api/payment/create-order")
    suspend fun createOrder(
        @Body request: CreateOrderRequest
    ): Response<CreateOrderResponse>

    @POST("api/payment/verify-signature")
    suspend fun verifySignature(
        @Body request: VerifySignatureRequest
    ): Response<VerifySignatureResponse>
}
