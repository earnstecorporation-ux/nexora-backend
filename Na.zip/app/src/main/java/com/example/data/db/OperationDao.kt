package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OperationDao {
    @Query("SELECT * FROM recent_operations ORDER BY timestamp DESC")
    fun getAllOperations(): Flow<List<RecentOperation>>

    @Query("SELECT * FROM recent_operations ORDER BY timestamp DESC LIMIT 5")
    fun getRecentOperations(): Flow<List<RecentOperation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOperation(operation: RecentOperation): Long

    @Delete
    suspend fun deleteOperation(operation: RecentOperation)

    @Query("DELETE FROM recent_operations")
    suspend fun clearAll()
}
