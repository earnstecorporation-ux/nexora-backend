package com.example.service

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.engine.PageMargin
import com.example.engine.PageOrientation
import com.example.engine.PdfGenerationConfig
import com.example.engine.SafeBitmapDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

/**
 * Result of a PDF conversion operation.
 */
sealed class PdfConversionResult {
    data class Success(
        val pdfFile: File,
        val pageCount: Int,
        val fileSizeBytes: Long,
        val originalSizeBytes: Long,
        val isTruncated: Boolean = false
    ) : PdfConversionResult()

    data class BatchLimitExceeded(
        val attemptedCount: Int,
        val maxAllowed: Int,
        val message: String
    ) : PdfConversionResult()

    data class Error(
        val throwable: Throwable,
        val message: String
    ) : PdfConversionResult()
}

/**
 * Service that utilizes Android's PdfDocument API to convert selected images
 * into a multi-page PDF, including support for free-tier batch limits.
 */
interface PdfConversionService {

    /**
     * Converts a list of image Uris into a multi-page PDF.
     *
     * @param imageUris The list of selected image Uris.
     * @param isPremium Whether the user has an active Pro subscription.
     * @param config Page orientation, margin, and output name options.
     * @param allowTruncateIfExceeded If true and free user exceeds limit, processes first 3 images. If false, returns BatchLimitExceeded.
     * @param onProgress Callback invoked as each page is rendered.
     */
    suspend fun convertImagesToPdf(
        imageUris: List<Uri>,
        isPremium: Boolean,
        config: PdfGenerationConfig = PdfGenerationConfig(),
        allowTruncateIfExceeded: Boolean = false,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): PdfConversionResult
}

/**
 * Default implementation using native Android PdfDocument and SafeBitmapDecoder.
 */
class DefaultPdfConversionService(
    private val context: Context
) : PdfConversionService {

    companion object {
        const val FREE_BATCH_LIMIT = 3
        private const val A4_WIDTH_POINTS = 595
        private const val A4_HEIGHT_POINTS = 842
    }

    override suspend fun convertImagesToPdf(
        imageUris: List<Uri>,
        isPremium: Boolean,
        config: PdfGenerationConfig,
        allowTruncateIfExceeded: Boolean,
        onProgress: (current: Int, total: Int) -> Unit
    ): PdfConversionResult = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) {
            return@withContext PdfConversionResult.Error(
                IllegalArgumentException("No images selected"),
                "Please select at least one image to create a PDF."
            )
        }

        // Enforce batch limit for free users
        val maxAllowed = if (isPremium) Int.MAX_VALUE else FREE_BATCH_LIMIT
        val effectiveUris: List<Uri>
        var isTruncated = false

        if (!isPremium && imageUris.size > maxAllowed) {
            if (allowTruncateIfExceeded) {
                effectiveUris = imageUris.take(maxAllowed)
                isTruncated = true
            } else {
                return@withContext PdfConversionResult.BatchLimitExceeded(
                    attemptedCount = imageUris.size,
                    maxAllowed = maxAllowed,
                    message = "Free tier allows up to $maxAllowed images per batch. Upgrade to Pro for unlimited conversions."
                )
            }
        } else {
            effectiveUris = imageUris
        }

        val pdfDocument = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val bgPaint = Paint().apply { color = Color.WHITE }

        try {
            val totalImages = effectiveUris.size
            var pagesRendered = 0
            var totalOriginalBytes = 0L

            for ((index, uri) in effectiveUris.withIndex()) {
                onProgress(index + 1, totalImages)

                val dims = SafeBitmapDecoder.inspectImage(context, uri)
                dims?.let { totalOriginalBytes += it.sizeBytes }

                // Decode bitmap safely to prevent OOM
                val bitmap = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                    context = context,
                    uri = uri,
                    reqWidth = 1800,
                    reqHeight = 2400
                ) ?: continue

                // Page dimensions based on orientation
                val isLandscape = when (config.orientation) {
                    PageOrientation.PORTRAIT -> false
                    PageOrientation.LANDSCAPE -> true
                    PageOrientation.AUTO -> bitmap.width > bitmap.height
                }

                val pageWidth = if (isLandscape) A4_HEIGHT_POINTS else A4_WIDTH_POINTS
                val pageHeight = if (isLandscape) A4_WIDTH_POINTS else A4_HEIGHT_POINTS

                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                // Fill background
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

                // Margin and aspect ratio scaling
                val margin = config.margin.points
                val availWidth = pageWidth - (margin * 2)
                val availHeight = pageHeight - (margin * 2)

                val scale = min(
                    availWidth.toFloat() / bitmap.width.toFloat(),
                    availHeight.toFloat() / bitmap.height.toFloat()
                )

                val scaledWidth = (bitmap.width * scale).toInt()
                val scaledHeight = (bitmap.height * scale).toInt()

                val left = margin + (availWidth - scaledWidth) / 2
                val top = margin + (availHeight - scaledHeight) / 2
                val destRect = Rect(left, top, left + scaledWidth, top + scaledHeight)

                canvas.drawBitmap(bitmap, null, destRect, paint)
                pdfDocument.finishPage(page)
                pagesRendered++

                bitmap.recycle()
            }

            if (pagesRendered == 0) {
                return@withContext PdfConversionResult.Error(
                    IllegalStateException("No valid images could be decoded"),
                    "Could not decode the selected images."
                )
            }

            // Write output file
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val baseName = if (config.fileName.isNotBlank()) {
                config.fileName.replace(".pdf", "")
            } else {
                "NEXORA_$timeStamp"
            }
            val outputFile = File(context.cacheDir, "$baseName.pdf")

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }

            PdfConversionResult.Success(
                pdfFile = outputFile,
                pageCount = pagesRendered,
                fileSizeBytes = outputFile.length(),
                originalSizeBytes = totalOriginalBytes,
                isTruncated = isTruncated
            )
        } catch (e: Exception) {
            PdfConversionResult.Error(e, e.localizedMessage ?: "Failed to generate PDF")
        } finally {
            pdfDocument.close()
        }
    }
}
