package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class ResizeOptions(
    val usePercentage: Boolean = true,
    val percentage: Int = 50,
    val targetWidth: Int = 1080,
    val targetHeight: Int = 1920,
    val maintainAspectRatio: Boolean = true
)

data class CompressionOptions(
    val quality: Int = 75,
    val format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG
)

data class ProcessedImageResult(
    val file: File,
    val originalSizeBytes: Long,
    val outputSizeBytes: Long,
    val width: Int,
    val height: Int
)

object ImageProcessor {

    /**
     * Resizes an image based on percentage or custom dimensions.
     */
    suspend fun resizeImage(
        context: Context,
        uri: Uri,
        options: ResizeOptions,
        outputQuality: Int = 90
    ): Result<ProcessedImageResult> = withContext(Dispatchers.IO) {
        try {
            val dimensions = SafeBitmapDecoder.inspectImage(context, uri)
                ?: return@withContext Result.failure(Exception("Unable to inspect image"))

            val originalWidth = dimensions.width
            val originalHeight = dimensions.height

            val (newWidth, newHeight) = if (options.usePercentage) {
                val scale = options.percentage.toFloat() / 100f
                val w = (originalWidth * scale).roundToInt().coerceAtLeast(1)
                val h = (originalHeight * scale).roundToInt().coerceAtLeast(1)
                Pair(w, h)
            } else {
                if (options.maintainAspectRatio) {
                    val aspectRatio = originalWidth.toFloat() / originalHeight.toFloat()
                    val w = options.targetWidth.coerceAtLeast(1)
                    val h = (w / aspectRatio).roundToInt().coerceAtLeast(1)
                    Pair(w, h)
                } else {
                    Pair(
                        options.targetWidth.coerceAtLeast(1),
                        options.targetHeight.coerceAtLeast(1)
                    )
                }
            }

            // Decode bitmap to reasonable bounds
            val sourceBitmap = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                context, uri, reqWidth = newWidth * 2, reqHeight = newHeight * 2
            ) ?: return@withContext Result.failure(Exception("Could not load image"))

            val scaledBitmap = Bitmap.createScaledBitmap(sourceBitmap, newWidth, newHeight, true)
            if (scaledBitmap != sourceBitmap) {
                sourceBitmap.recycle()
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(context.cacheDir, "Resized_$timeStamp.jpg")

            FileOutputStream(outputFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, outputQuality, out)
            }
            scaledBitmap.recycle()

            Result.success(
                ProcessedImageResult(
                    file = outputFile,
                    originalSizeBytes = dimensions.sizeBytes,
                    outputSizeBytes = outputFile.length(),
                    width = newWidth,
                    height = newHeight
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Estimates output size for the given quality slider value quickly.
     */
    suspend fun estimateCompressedSize(
        context: Context,
        uri: Uri,
        quality: Int
    ): Long = withContext(Dispatchers.IO) {
        try {
            val sampledBitmap = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                context, uri, reqWidth = 1200, reqHeight = 1200
            ) ?: return@withContext 0L

            val stream = ByteArrayOutputStream()
            sampledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            val sampleBytes = stream.size()
            sampledBitmap.recycle()

            // Scale estimate to full resolution
            val dims = SafeBitmapDecoder.inspectImage(context, uri)
            if (dims != null && dims.width > 1200) {
                val ratio = (dims.width.toFloat() * dims.height) / (1200f * 1200f)
                val estimated = (sampleBytes * Math.sqrt(ratio.toDouble())).toLong()
                return@withContext estimated.coerceAtLeast(sampleBytes.toLong())
            }
            sampleBytes.toLong()
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Compresses the image to the specified quality.
     */
    suspend fun compressImage(
        context: Context,
        uri: Uri,
        options: CompressionOptions
    ): Result<ProcessedImageResult> = withContext(Dispatchers.IO) {
        try {
            val dimensions = SafeBitmapDecoder.inspectImage(context, uri)
                ?: return@withContext Result.failure(Exception("Unable to inspect image"))

            val bitmap = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                context, uri, reqWidth = 2400, reqHeight = 2400
            ) ?: return@withContext Result.failure(Exception("Could not load image"))

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val extension = if (options.format == Bitmap.CompressFormat.WEBP) "webp" else "jpg"
            val outputFile = File(context.cacheDir, "Compressed_$timeStamp.$extension")

            FileOutputStream(outputFile).use { out ->
                bitmap.compress(options.format, options.quality, out)
            }

            val result = ProcessedImageResult(
                file = outputFile,
                originalSizeBytes = dimensions.sizeBytes,
                outputSizeBytes = outputFile.length(),
                width = bitmap.width,
                height = bitmap.height
            )
            bitmap.recycle()

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
