package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

enum class PageOrientation {
    PORTRAIT,
    LANDSCAPE,
    AUTO
}

enum class PageMargin(val points: Int) {
    NONE(0),
    NARROW(18),
    NORMAL(36)
}

data class PdfGenerationConfig(
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val margin: PageMargin = PageMargin.NORMAL,
    val fileName: String = ""
)

object PdfGenerator {

    // Standard A4 dimensions in PostScript points (72 points per inch)
    private const val A4_WIDTH = 595
    private const val A4_HEIGHT = 842

    suspend fun generatePdfFromImages(
        context: Context,
        imageUris: List<Uri>,
        config: PdfGenerationConfig,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<File> = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No images selected"))
        }

        val pdfDocument = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val bgPaint = Paint().apply { color = Color.WHITE }

        try {
            val totalImages = imageUris.size
            for ((index, uri) in imageUris.withIndex()) {
                onProgress(index + 1, totalImages)

                // Decode bitmap safely
                val bitmap = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                    context = context,
                    uri = uri,
                    reqWidth = 1800,
                    reqHeight = 2400
                ) ?: continue

                // Determine page dimensions
                val isLandscape = when (config.orientation) {
                    PageOrientation.PORTRAIT -> false
                    PageOrientation.LANDSCAPE -> true
                    PageOrientation.AUTO -> bitmap.width > bitmap.height
                }

                val pageWidth = if (isLandscape) A4_HEIGHT else A4_WIDTH
                val pageHeight = if (isLandscape) A4_WIDTH else A4_HEIGHT

                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                // Fill background
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

                // Calculate printable area with margin
                val margin = config.margin.points
                val availWidth = pageWidth - (margin * 2)
                val availHeight = pageHeight - (margin * 2)

                // Calculate aspect ratio fit
                val scale = min(
                    availWidth.toFloat() / bitmap.width.toFloat(),
                    availHeight.toFloat() / bitmap.height.toFloat()
                )

                val scaledWidth = (bitmap.width * scale).toInt()
                val scaledHeight = (bitmap.height * scale).toInt()

                // Center image
                val left = margin + (availWidth - scaledWidth) / 2
                val top = margin + (availHeight - scaledHeight) / 2
                val destRect = Rect(left, top, left + scaledWidth, top + scaledHeight)

                canvas.drawBitmap(bitmap, null, destRect, paint)
                pdfDocument.finishPage(page)

                bitmap.recycle()
            }

            // Save PDF to cache file
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val baseName = if (config.fileName.isNotBlank()) {
                config.fileName.replace(".pdf", "")
            } else {
                "NEXORA_$timeStamp"
            }
            val outputFile = File(context.cacheDir, "$baseName.pdf")

            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }

            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            pdfDocument.close()
        }
    }
}
