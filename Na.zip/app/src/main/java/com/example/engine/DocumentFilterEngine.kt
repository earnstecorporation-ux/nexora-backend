package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

enum class DocumentFilter(val label: String) {
    ORIGINAL("Original"),
    DOCUMENT_BW("Clean B&W"),
    GRAYSCALE("Grayscale"),
    COLOR_ENHANCE("Vivid Color")
}

object DocumentFilterEngine {

    fun applyFilter(source: Bitmap, filter: DocumentFilter): Bitmap {
        if (filter == DocumentFilter.ORIGINAL) {
            return source
        }

        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (filter) {
            DocumentFilter.DOCUMENT_BW -> {
                // High contrast document filter: convert to grayscale then sharply boost contrast
                val matrix = ColorMatrix().apply {
                    setSaturation(0f)
                }
                // High contrast curve: scale RGB and shift
                val contrast = 1.8f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                val contrastMatrix = ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                matrix.postConcat(contrastMatrix)
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            DocumentFilter.GRAYSCALE -> {
                val matrix = ColorMatrix().apply {
                    setSaturation(0f)
                }
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            DocumentFilter.COLOR_ENHANCE -> {
                // Enhanced color: 1.35x saturation and 1.2x contrast
                val satMatrix = ColorMatrix().apply {
                    setSaturation(1.35f)
                }
                val contrast = 1.2f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                val contrastMatrix = ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                satMatrix.postConcat(contrastMatrix)
                paint.colorFilter = ColorMatrixColorFilter(satMatrix)
            }
            DocumentFilter.ORIGINAL -> {}
        }

        canvas.drawBitmap(source, 0f, 0f, paint)
        return result
    }
}
