package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.ui.components.AppTopBar
import com.example.ui.components.PocketBottomNav
import com.example.ui.screens.CompressScreen
import com.example.ui.screens.DocScanScreen
import com.example.ui.screens.FilesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PdfConverterScreen
import com.example.ui.screens.PremiumScreen
import com.example.ui.screens.ResizeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NexoraTheme
import com.example.ui.viewmodel.ActiveTool
import com.example.ui.viewmodel.NavDestination
import com.example.ui.viewmodel.PocketToolsViewModel
import com.example.ui.viewmodel.RazorpayCheckoutPayload
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity(), PaymentResultWithDataListener {

    private val viewModel: PocketToolsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Observe Razorpay checkout requests from ViewModel
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.razorpayCheckoutEvent.collect { payload ->
                    launchRazorpayCheckout(payload)
                }
            }
        }

        setContent {
            NexoraTheme {
                NexoraRootRouter(viewModel = viewModel)
            }
        }
    }

    private fun launchRazorpayCheckout(payload: RazorpayCheckoutPayload) {
        try {
            val checkout = Checkout()
            checkout.setKeyID(payload.keyId)

            val options = JSONObject()
            options.put("name", payload.name)
            options.put("description", payload.description)
            options.put("currency", payload.currency)
            options.put("amount", payload.amountPaise)
            options.put("order_id", payload.orderId)

            val theme = JSONObject()
            theme.put("color", "#3285FF") // NEXORA Electric blue
            options.put("theme", theme)

            val prefill = JSONObject()
            if (payload.prefillEmail.isNotBlank()) {
                prefill.put("email", payload.prefillEmail)
            }
            if (payload.prefillContact.isNotBlank()) {
                prefill.put("contact", payload.prefillContact)
            }
            options.put("prefill", prefill)

            val retryObj = JSONObject()
            retryObj.put("enabled", true)
            retryObj.put("max_count", 4)
            options.put("retry", retryObj)

            checkout.open(this, options)
        } catch (e: Exception) {
            viewModel.onPaymentError(-1, "Unable to launch Razorpay checkout: ${e.localizedMessage ?: "Initialization error"}", null)
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?, paymentData: PaymentData?) {
        viewModel.onPaymentSuccess(paymentData)
    }

    override fun onPaymentError(errorCode: Int, response: String?, paymentData: PaymentData?) {
        viewModel.onPaymentError(errorCode, response, paymentData)
    }
}

@Composable
fun NexoraRootRouter(
    viewModel: PocketToolsViewModel
) {
    val snackBarMessage by viewModel.snackBarMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackBarMessage) {
        snackBarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    NexoraApp(viewModel = viewModel, snackbarHostState = snackbarHostState)
}

@Composable
fun NexoraApp(
    viewModel: PocketToolsViewModel,
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() }
) {
    val currentNav by viewModel.currentNav.collectAsState()
    val activeTool by viewModel.activeTool.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()

    // Secondary screen back handler
    if (activeTool == ActiveTool.NONE && currentNav != NavDestination.HOME) {
        BackHandler {
            viewModel.navigateTo(NavDestination.HOME)
        }
    }

    // Active tool takes over the screen with dedicated back button
    if (activeTool != ActiveTool.NONE) {
        when (activeTool) {
            ActiveTool.PDF_CONVERTER -> PdfConverterScreen(viewModel = viewModel, onBack = { viewModel.closeTool() })
            ActiveTool.COMPRESS -> CompressScreen(viewModel = viewModel, onBack = { viewModel.closeTool() })
            ActiveTool.RESIZE -> ResizeScreen(viewModel = viewModel, onBack = { viewModel.closeTool() })
            ActiveTool.DOC_SCAN -> DocScanScreen(viewModel = viewModel, onBack = { viewModel.closeTool() })
            ActiveTool.NONE -> {}
        }
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                AppTopBar(
                    isPremium = isPremium,
                    onPlanBadgeClick = { viewModel.navigateTo(NavDestination.PREMIUM) }
                )
            },
            bottomBar = {
                PocketBottomNav(
                    currentNav = currentNav,
                    onNavSelect = { viewModel.navigateTo(it) }
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentNav,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "NavTransition"
                ) { target ->
                    when (target) {
                        NavDestination.HOME -> HomeScreen(viewModel = viewModel)
                        NavDestination.FILES -> FilesScreen(viewModel = viewModel)
                        NavDestination.PREMIUM -> PremiumScreen(viewModel = viewModel)
                        NavDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
