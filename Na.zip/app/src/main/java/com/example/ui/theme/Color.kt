package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXORA Brand Color Palette
// Background: Midnight navy #050816
val NexoraBackground = Color(0xFF050816)
val NexoraSecondaryBackground = Color(0xFF0B1228)

// Cards & Surfaces: #101B35
val NexoraCard = Color(0xFF101B35)
val NexoraCardElevated = Color(0xFF16254A)

// Primary Accent: Electric blue #3285FF
val NexoraElectricBlue = Color(0xFF3285FF)
val NexoraElectricBlueDark = Color(0xFF1F60C2)
val NexoraElectricBlueContainer = Color(0xFF1A3870)

// Secondary Accent: Sky blue #58D5FF
val NexoraSkyBlue = Color(0xFF58D5FF)
val NexoraSkyBlueContainer = Color(0xFF0E3854)

// Main Text: #F4F8FF
val NexoraMainText = Color(0xFFF4F8FF)
val NexoraMutedText = Color(0xFF94A7CB)
val NexoraDimText = Color(0xFF6B80A8)

// Borders & Dividers
val NexoraOutline = Color(0xFF1E2D52)
val NexoraOutlineVariant = Color(0xFF2B3F6E)

// Status & Accents
val NexoraGold = Color(0xFFFFC043)
val NexoraSuccess = Color(0xFF00E5A3)
val NexoraError = Color(0xFFFF5252)
