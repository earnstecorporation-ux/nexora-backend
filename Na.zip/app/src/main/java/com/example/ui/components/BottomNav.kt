package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.viewmodel.NavDestination

@Composable
fun PocketBottomNav(
    currentNav: NavDestination,
    onNavSelect: (NavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .testTag("bottom_nav_bar")
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = MaterialTheme.colorScheme.surfaceVariant.let { androidx.compose.ui.unit.Dp(3f) }
    ) {
        NavigationBarItem(
            modifier = Modifier.testTag("nav_home"),
            selected = currentNav == NavDestination.HOME,
            onClick = { onNavSelect(NavDestination.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentNav == NavDestination.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary
            )
        )

        NavigationBarItem(
            modifier = Modifier.testTag("nav_files"),
            selected = currentNav == NavDestination.FILES,
            onClick = { onNavSelect(NavDestination.FILES) },
            icon = {
                Icon(
                    imageVector = if (currentNav == NavDestination.FILES) Icons.Filled.Folder else Icons.Outlined.Folder,
                    contentDescription = "Files"
                )
            },
            label = { Text("Files") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary
            )
        )

        NavigationBarItem(
            modifier = Modifier.testTag("nav_premium"),
            selected = currentNav == NavDestination.PREMIUM,
            onClick = { onNavSelect(NavDestination.PREMIUM) },
            icon = {
                Icon(
                    imageVector = if (currentNav == NavDestination.PREMIUM) Icons.Filled.Star else Icons.Outlined.Star,
                    contentDescription = "Premium"
                )
            },
            label = { Text("Premium") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary
            )
        )

        NavigationBarItem(
            modifier = Modifier.testTag("nav_settings"),
            selected = currentNav == NavDestination.SETTINGS,
            onClick = { onNavSelect(NavDestination.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (currentNav == NavDestination.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = { Text("Settings") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}
