package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NexoraColorScheme = darkColorScheme(
    primary = NexoraElectricBlue,
    onPrimary = NexoraMainText,
    primaryContainer = NexoraElectricBlueContainer,
    onPrimaryContainer = NexoraSkyBlue,
    secondary = NexoraSkyBlue,
    onSecondary = NexoraBackground,
    secondaryContainer = NexoraSkyBlueContainer,
    onSecondaryContainer = NexoraSkyBlue,
    background = NexoraBackground,
    onBackground = NexoraMainText,
    surface = NexoraCard,
    onSurface = NexoraMainText,
    surfaceVariant = NexoraSecondaryBackground,
    onSurfaceVariant = NexoraMutedText,
    outline = NexoraOutline,
    outlineVariant = NexoraOutlineVariant,
    error = NexoraError,
    onError = NexoraMainText
)

@Composable
fun NexoraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexoraColorScheme,
        typography = Typography,
        content = content
    )
}

// Aliases for seamless backward compatibility
@Composable
fun PocketToolsTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NexoraTheme(content = content)
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NexoraTheme(content = content)
}
