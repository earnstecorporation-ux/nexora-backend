package com.example.ui.viewmodel

data class RazorpayCheckoutPayload(
    val keyId: String,
    val orderId: String,
    val amountPaise: Long,
    val currency: String,
    val name: String,
    val description: String,
    val prefillEmail: String = "",
    val prefillContact: String = ""
)

sealed class PaymentFlowState {
    object Idle : PaymentFlowState()
    object CreatingOrder : PaymentFlowState()
    data class AwaitingCheckout(val orderId: String) : PaymentFlowState()
    data class VerifyingSignature(val orderId: String, val paymentId: String) : PaymentFlowState()
    data class VerifiedSuccess(val orderId: String, val paymentId: String, val verifiedAt: Long) : PaymentFlowState()
    data class Cancelled(val message: String) : PaymentFlowState()
    data class Error(val message: String, val canRetryVerification: Boolean = false) : PaymentFlowState()
}
