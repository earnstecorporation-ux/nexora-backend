package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.PocketToolsDatabase
import com.example.data.db.RecentOperation
import com.example.data.repository.HistoryRepository
import com.example.engine.CompressionOptions
import com.example.engine.DocumentFilter
import com.example.engine.DocumentFilterEngine
import com.example.engine.FileExportManager
import com.example.engine.ImageProcessor
import com.example.engine.PageMargin
import com.example.engine.PageOrientation
import com.example.engine.PdfGenerationConfig
import com.example.engine.ProcessedImageResult
import com.example.engine.ResizeOptions
import com.example.engine.SafeBitmapDecoder
import com.example.BuildConfig
import com.example.data.payment.repository.PaymentRepository
import com.example.data.payment.repository.PendingVerification
import com.example.data.payment.repository.PremiumEntitlementManager
import com.example.data.payment.repository.VerifiedEntitlement
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class NavDestination {
    HOME,
    FILES,
    PREMIUM,
    SETTINGS
}

enum class ActiveTool {
    NONE,
    PDF_CONVERTER,
    COMPRESS,
    RESIZE,
    DOC_SCAN
}

class PocketToolsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = PocketToolsDatabase.getDatabase(application)
    val historyRepository = HistoryRepository(db.operationDao())

    val pdfConversionService: com.example.service.PdfConversionService =
        com.example.service.DefaultPdfConversionService(application)

    val recentOperations = historyRepository.recentOperations.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val allOperations = historyRepository.allOperations.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val entitlementManager = PremiumEntitlementManager(application)
    val paymentRepository = PaymentRepository(
        entitlementManager = entitlementManager,
        defaultBackendUrl = BuildConfig.PAYMENT_BACKEND_URL,
        defaultRazorpayKeyId = BuildConfig.RAZORPAY_KEY_ID
    )

    val verifiedEntitlement: StateFlow<VerifiedEntitlement> = entitlementManager.entitlement
    val pendingVerification: StateFlow<PendingVerification?> = entitlementManager.pendingVerification

    val isPremium: StateFlow<Boolean> = entitlementManager.entitlement
        .map { it.isPremium }
        .stateIn(viewModelScope, SharingStarted.Eagerly, entitlementManager.isPremium)

    private val _paymentState = MutableStateFlow<PaymentFlowState>(PaymentFlowState.Idle)
    val paymentState: StateFlow<PaymentFlowState> = _paymentState.asStateFlow()

    private val _razorpayCheckoutEvent = MutableSharedFlow<RazorpayCheckoutPayload>(replay = 0)
    val razorpayCheckoutEvent: SharedFlow<RazorpayCheckoutPayload> = _razorpayCheckoutEvent.asSharedFlow()

    private val _currentNav = MutableStateFlow(NavDestination.HOME)
    val currentNav: StateFlow<NavDestination> = _currentNav.asStateFlow()

    private val _activeTool = MutableStateFlow(ActiveTool.NONE)
    val activeTool: StateFlow<ActiveTool> = _activeTool.asStateFlow()

    private val _snackBarMessage = MutableStateFlow<String?>(null)
    val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()

    // --- PDF Converter State ---
    val pdfSelectedImages = MutableStateFlow<List<Uri>>(emptyList())
    val pdfOrientation = MutableStateFlow(PageOrientation.PORTRAIT)
    val pdfMargin = MutableStateFlow(PageMargin.NORMAL)
    val pdfCustomName = MutableStateFlow("")
    val isPdfGenerating = MutableStateFlow(false)
    val pdfProgress = MutableStateFlow(Pair(0, 0)) // current, total
    val generatedPdfFile = MutableStateFlow<File?>(null)

    // --- Compression State ---
    val compressSelectedUri = MutableStateFlow<Uri?>(null)
    val compressOriginalDims = MutableStateFlow<SafeBitmapDecoder.ImageDimensions?>(null)
    val compressQuality = MutableStateFlow(75f)
    val compressEstimatedBytes = MutableStateFlow(0L)
    val isCompressing = MutableStateFlow(false)
    val compressedResult = MutableStateFlow<ProcessedImageResult?>(null)
    private var estimateJob: Job? = null

    // --- Resize State ---
    val resizeSelectedUri = MutableStateFlow<Uri?>(null)
    val resizeOriginalDims = MutableStateFlow<SafeBitmapDecoder.ImageDimensions?>(null)
    val resizePercentage = MutableStateFlow(50)
    val resizeCustomWidth = MutableStateFlow(1080)
    val resizeCustomHeight = MutableStateFlow(1920)
    val resizeUsePercentage = MutableStateFlow(true)
    val resizeLockRatio = MutableStateFlow(true)
    val isResizing = MutableStateFlow(false)
    val resizedResult = MutableStateFlow<ProcessedImageResult?>(null)

    // --- Document Scanner State ---
    val scanCapturedUri = MutableStateFlow<Uri?>(null)
    val scanActiveFilter = MutableStateFlow(DocumentFilter.DOCUMENT_BW)
    val scanPreviewBitmap = MutableStateFlow<Bitmap?>(null)
    val isScanProcessing = MutableStateFlow(false)
    val scanExportedFile = MutableStateFlow<File?>(null)

    val pendingExportFile = MutableStateFlow<File?>(null)

    fun navigateTo(destination: NavDestination) {
        _currentNav.value = destination
    }

    fun openTool(tool: ActiveTool) {
        _activeTool.value = tool
    }

    fun closeTool() {
        _activeTool.value = ActiveTool.NONE
        resetToolStates()
    }

    fun showMessage(msg: String) {
        _snackBarMessage.value = msg
    }

    fun clearMessage() {
        _snackBarMessage.value = null
    }

    // ==========================================
    // PDF CONVERTER ACTIONS
    // ==========================================

    fun onImagesPickedForPdf(uris: List<Uri>) {
        pdfSelectedImages.value = uris
        generatedPdfFile.value = null
    }

    fun removePdfImage(index: Int) {
        val current = pdfSelectedImages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            pdfSelectedImages.value = current
        }
    }

    fun movePdfImage(from: Int, to: Int) {
        val current = pdfSelectedImages.value.toMutableList()
        if (from in current.indices && to in current.indices) {
            val item = current.removeAt(from)
            current.add(to, item)
            pdfSelectedImages.value = current
        }
    }

    fun generatePdf() {
        val uris = pdfSelectedImages.value
        if (uris.isEmpty()) {
            showMessage("Please select at least 1 image")
            return
        }

        viewModelScope.launch {
            isPdfGenerating.value = true
            val config = PdfGenerationConfig(
                orientation = pdfOrientation.value,
                margin = pdfMargin.value,
                fileName = pdfCustomName.value
            )

            val conversionResult = pdfConversionService.convertImagesToPdf(
                imageUris = uris,
                isPremium = isPremium.value,
                config = config,
                allowTruncateIfExceeded = true,
                onProgress = { cur, tot ->
                    pdfProgress.value = Pair(cur, tot)
                }
            )

            isPdfGenerating.value = false
            when (conversionResult) {
                is com.example.service.PdfConversionResult.Success -> {
                    val file = conversionResult.pdfFile
                    generatedPdfFile.value = file
                    pendingExportFile.value = file
                    historyRepository.recordOperation(
                        title = file.name,
                        toolType = "PDF",
                        filePath = file.absolutePath,
                        fileUri = "",
                        originalSizeBytes = conversionResult.originalSizeBytes,
                        outputSizeBytes = conversionResult.fileSizeBytes,
                        details = "${conversionResult.pageCount} pages • ${pdfOrientation.value.name.lowercase()}"
                    )
                    showMessage("PDF created successfully: ${file.name}")
                }
                is com.example.service.PdfConversionResult.BatchLimitExceeded -> {
                    showMessage(conversionResult.message)
                }
                is com.example.service.PdfConversionResult.Error -> {
                    showMessage("PDF error: ${conversionResult.message}")
                }
            }
        }
    }

    // ==========================================
    // COMPRESS ACTIONS
    // ==========================================

    fun onImageSelectedForCompress(uri: Uri) {
        compressSelectedUri.value = uri
        compressedResult.value = null
        val dims = SafeBitmapDecoder.inspectImage(getApplication(), uri)
        compressOriginalDims.value = dims
        updateEstimatedCompressedSize(compressQuality.value.toInt())
    }

    fun onCompressQualityChanged(quality: Float) {
        compressQuality.value = quality
        estimateJob?.cancel()
        estimateJob = viewModelScope.launch {
            delay(150)
            updateEstimatedCompressedSize(quality.toInt())
        }
    }

    private fun updateEstimatedCompressedSize(quality: Int) {
        val uri = compressSelectedUri.value ?: return
        viewModelScope.launch {
            val estimated = ImageProcessor.estimateCompressedSize(getApplication(), uri, quality)
            compressEstimatedBytes.value = estimated
        }
    }

    fun executeCompression() {
        val uri = compressSelectedUri.value ?: return
        viewModelScope.launch {
            isCompressing.value = true
            val options = CompressionOptions(quality = compressQuality.value.toInt())
            val res = ImageProcessor.compressImage(getApplication(), uri, options)
            isCompressing.value = false

            res.onSuccess { result ->
                compressedResult.value = result
                pendingExportFile.value = result.file
                val savedPercent = if (result.originalSizeBytes > 0) {
                    ((result.originalSizeBytes - result.outputSizeBytes) * 100 / result.originalSizeBytes)
                } else 0
                historyRepository.recordOperation(
                    title = result.file.name,
                    toolType = "COMPRESS",
                    filePath = result.file.absolutePath,
                    fileUri = "",
                    originalSizeBytes = result.originalSizeBytes,
                    outputSizeBytes = result.outputSizeBytes,
                    details = "Quality ${options.quality}% • Saved $savedPercent%"
                )
                showMessage("Compressed: ${FileExportManager.formatBytes(result.outputSizeBytes)}")
            }.onFailure { err ->
                showMessage("Compression error: ${err.localizedMessage ?: "Failed"}")
            }
        }
    }

    // ==========================================
    // RESIZE ACTIONS
    // ==========================================

    fun onImageSelectedForResize(uri: Uri) {
        resizeSelectedUri.value = uri
        resizedResult.value = null
        val dims = SafeBitmapDecoder.inspectImage(getApplication(), uri)
        resizeOriginalDims.value = dims
        dims?.let {
            resizeCustomWidth.value = it.width / 2
            resizeCustomHeight.value = it.height / 2
        }
    }

    fun onCustomWidthChanged(newW: Int) {
        resizeCustomWidth.value = newW
        if (resizeLockRatio.value) {
            val dims = resizeOriginalDims.value
            if (dims != null && dims.width > 0) {
                val ratio = dims.width.toFloat() / dims.height.toFloat()
                resizeCustomHeight.value = (newW / ratio).toInt().coerceAtLeast(1)
            }
        }
    }

    fun onCustomHeightChanged(newH: Int) {
        resizeCustomHeight.value = newH
        if (resizeLockRatio.value) {
            val dims = resizeOriginalDims.value
            if (dims != null && dims.height > 0) {
                val ratio = dims.width.toFloat() / dims.height.toFloat()
                resizeCustomWidth.value = (newH * ratio).toInt().coerceAtLeast(1)
            }
        }
    }

    fun executeResize() {
        val uri = resizeSelectedUri.value ?: return
        viewModelScope.launch {
            isResizing.value = true
            val options = ResizeOptions(
                usePercentage = resizeUsePercentage.value,
                percentage = resizePercentage.value,
                targetWidth = resizeCustomWidth.value,
                targetHeight = resizeCustomHeight.value,
                maintainAspectRatio = resizeLockRatio.value
            )
            val res = ImageProcessor.resizeImage(getApplication(), uri, options)
            isResizing.value = false

            res.onSuccess { result ->
                resizedResult.value = result
                pendingExportFile.value = result.file
                historyRepository.recordOperation(
                    title = result.file.name,
                    toolType = "RESIZE",
                    filePath = result.file.absolutePath,
                    fileUri = "",
                    originalSizeBytes = result.originalSizeBytes,
                    outputSizeBytes = result.outputSizeBytes,
                    details = "${result.width}x${result.height} px"
                )
                showMessage("Resized to ${result.width}x${result.height} px")
            }.onFailure { err ->
                showMessage("Resize error: ${err.localizedMessage ?: "Failed"}")
            }
        }
    }

    // ==========================================
    // DOCUMENT SCANNER ACTIONS
    // ==========================================

    fun onPhotoCapturedOrPicked(uri: Uri) {
        scanCapturedUri.value = uri
        scanExportedFile.value = null
        applyScanFilter(scanActiveFilter.value)
    }

    fun applyScanFilter(filter: DocumentFilter) {
        scanActiveFilter.value = filter
        val uri = scanCapturedUri.value ?: return
        viewModelScope.launch {
            isScanProcessing.value = true
            val source = SafeBitmapDecoder.decodeSampledBitmapFromUri(
                getApplication(), uri, reqWidth = 1600, reqHeight = 2200
            )
            if (source != null) {
                val processed = DocumentFilterEngine.applyFilter(source, filter)
                scanPreviewBitmap.value = processed
            }
            isScanProcessing.value = false
        }
    }

    fun exportScannedDoc(asPdf: Boolean) {
        val bitmap = scanPreviewBitmap.value ?: return
        viewModelScope.launch {
            isScanProcessing.value = true
            try {
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val outFile = if (asPdf) {
                    val tempImgFile = File(getApplication<Application>().cacheDir, "scan_temp_$timeStamp.jpg")
                    FileOutputStream(tempImgFile).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    val config = PdfGenerationConfig(
                        orientation = PageOrientation.AUTO,
                        margin = PageMargin.NONE,
                        fileName = "NEXORA_Scan_$timeStamp.pdf"
                    )
                    val pdfRes = pdfConversionService.convertImagesToPdf(
                        imageUris = listOf(Uri.fromFile(tempImgFile)),
                        isPremium = true,
                        config = config
                    )
                    tempImgFile.delete()
                    when (pdfRes) {
                        is com.example.service.PdfConversionResult.Success -> pdfRes.pdfFile
                        else -> throw Exception("Failed to generate PDF")
                    }
                } else {
                    val imgFile = File(getApplication<Application>().cacheDir, "NEXORA_Scan_$timeStamp.jpg")
                    FileOutputStream(imgFile).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    imgFile
                }

                scanExportedFile.value = outFile
                pendingExportFile.value = outFile
                val origSize = scanCapturedUri.value?.let {
                    SafeBitmapDecoder.inspectImage(getApplication(), it)?.sizeBytes
                } ?: outFile.length()

                historyRepository.recordOperation(
                    title = outFile.name,
                    toolType = "SCAN",
                    filePath = outFile.absolutePath,
                    fileUri = "",
                    originalSizeBytes = origSize,
                    outputSizeBytes = outFile.length(),
                    details = "${scanActiveFilter.value.label} • ${if (asPdf) "PDF" else "JPEG"}"
                )
                showMessage("Document exported: ${outFile.name}")
            } catch (e: Exception) {
                showMessage("Export failed: ${e.localizedMessage ?: "Unknown error"}")
            } finally {
                isScanProcessing.value = false
            }
        }
    }

    fun onSaveToSafDestination(targetUri: Uri) {
        val file = pendingExportFile.value ?: return
        viewModelScope.launch {
            val res = FileExportManager.saveToDestinationUri(getApplication(), file, targetUri)
            res.onSuccess {
                showMessage("File saved successfully to chosen folder!")
            }.onFailure { err ->
                showMessage("Failed to save: ${err.localizedMessage ?: "Permission error"}")
            }
        }
    }

    fun deleteRecentOperation(op: RecentOperation) {
        viewModelScope.launch {
            historyRepository.deleteOperation(op)
            showMessage("Record removed")
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepository.clearHistory()
            showMessage("History cleared")
        }
    }

    fun clearAppCache() {
        viewModelScope.launch {
            try {
                val cache = getApplication<Application>().cacheDir
                cache.listFiles()?.forEach { it.delete() }
                showMessage("Cache cleaned up")
            } catch (e: Exception) {
                showMessage("Error clearing cache: ${e.message}")
            }
        }
    }

    // ==========================================
    // RAZORPAY PAYMENT & VERIFICATION ACTIONS
    // ==========================================

    fun initiateLifetimePurchase(userEmail: String = "", userContact: String = "") {
        if (isPremium.value) {
            showMessage("NEXORA Lifetime Premium is already active on this device!")
            return
        }
        viewModelScope.launch {
            _paymentState.value = PaymentFlowState.CreatingOrder
            val receipt = "nexora_${System.currentTimeMillis()}"
            val result = paymentRepository.createOrder(receipt)
            result.onSuccess { orderResp ->
                _paymentState.value = PaymentFlowState.AwaitingCheckout(orderResp.orderId)
                val keyToUse = if (orderResp.keyId.isNotBlank()) {
                    orderResp.keyId
                } else {
                    paymentRepository.getEffectiveRazorpayKeyId()
                }
                _razorpayCheckoutEvent.emit(
                    RazorpayCheckoutPayload(
                        keyId = keyToUse,
                        orderId = orderResp.orderId,
                        amountPaise = orderResp.amount,
                        currency = orderResp.currency,
                        name = "NEXORA",
                        description = "Lifetime Premium Upgrade (One-Time ₹49)",
                        prefillEmail = userEmail,
                        prefillContact = userContact
                    )
                )
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Failed to create order on payment server"
                _paymentState.value = PaymentFlowState.Error(msg, canRetryVerification = false)
                showMessage("Order creation error: $msg")
            }
        }
    }

    fun onPaymentSuccess(paymentData: com.razorpay.PaymentData?) {
        val orderId = paymentData?.orderId.orEmpty()
        val paymentId = paymentData?.paymentId.orEmpty()
        val signature = paymentData?.signature.orEmpty()

        if (orderId.isBlank() || paymentId.isBlank() || signature.isBlank()) {
            _paymentState.value = PaymentFlowState.Error(
                "Incomplete payment response from checkout.",
                canRetryVerification = false
            )
            showMessage("Payment error: Missing payment details")
            return
        }

        viewModelScope.launch {
            // "Unlock Premium only after trusted payment verification, not merely when checkout screen reports success"
            _paymentState.value = PaymentFlowState.VerifyingSignature(orderId, paymentId)
            val result = paymentRepository.verifyPayment(
                orderId = orderId,
                paymentId = paymentId,
                signature = signature
            )
            result.onSuccess { verifyResp ->
                _paymentState.value = PaymentFlowState.VerifiedSuccess(
                    orderId = orderId,
                    paymentId = paymentId,
                    verifiedAt = verifyResp.verifiedAt
                )
                showMessage("🎉 Payment verified! NEXORA Lifetime Premium unlocked.")
            }.onFailure { err ->
                val errorMsg = err.localizedMessage ?: "Cryptographic signature verification failed"
                _paymentState.value = PaymentFlowState.Error(
                    message = errorMsg,
                    canRetryVerification = true
                )
                showMessage("Verification notice: $errorMsg")
            }
        }
    }

    fun onPaymentError(errorCode: Int, description: String?, paymentData: com.razorpay.PaymentData?) {
        val msg = description ?: "Payment error (Code: $errorCode)"
        if (errorCode == com.razorpay.Checkout.PAYMENT_CANCELED) {
            _paymentState.value = PaymentFlowState.Cancelled("Payment checkout was cancelled.")
            showMessage("Payment cancelled.")
        } else {
            _paymentState.value = PaymentFlowState.Error(msg, canRetryVerification = false)
            showMessage("Payment failed: $msg")
        }
    }

    fun retryPendingVerification() {
        val pending = entitlementManager.pendingVerification.value
        if (pending == null) {
            showMessage("No pending verification found.")
            return
        }
        viewModelScope.launch {
            _paymentState.value = PaymentFlowState.VerifyingSignature(pending.orderId, pending.paymentId)
            val result = paymentRepository.retryPendingVerification()
            result.onSuccess { verifyResp ->
                _paymentState.value = PaymentFlowState.VerifiedSuccess(
                    orderId = pending.orderId,
                    paymentId = pending.paymentId,
                    verifiedAt = verifyResp.verifiedAt
                )
                showMessage("🎉 Payment verified! Lifetime Premium active.")
            }.onFailure { err ->
                val errorMsg = err.localizedMessage ?: "Verification retry failed"
                _paymentState.value = PaymentFlowState.Error(errorMsg, canRetryVerification = true)
                showMessage("Verification error: $errorMsg")
            }
        }
    }

    fun testBackendConnection(url: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = paymentRepository.testBackendConnection(url)
            result.onSuccess { health ->
                val msg = "Connected to ${health.service} (${health.mode} mode). Backend Razorpay credentials configured: ${if (health.keyConfigured) "Yes" else "No (Set RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET in backend environment)"}."
                onResult(true, msg)
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Connection failed"
                onResult(false, msg)
            }
        }
    }

    fun setCustomBackendUrl(url: String) {
        paymentRepository.setEffectiveBackendUrl(url)
        showMessage("Backend URL updated to: ${paymentRepository.getEffectiveBackendUrl()}")
    }

    fun setCustomRazorpayKey(key: String) {
        paymentRepository.setEffectiveRazorpayKeyId(key)
        showMessage("Razorpay Key ID updated.")
    }

    fun resetEntitlementForTesting() {
        entitlementManager.resetForTesting()
        _paymentState.value = PaymentFlowState.Idle
        showMessage("Entitlement reset. Free tier active.")
    }

    fun resetPaymentFlowState() {
        _paymentState.value = PaymentFlowState.Idle
    }

    private fun resetToolStates() {
        pdfSelectedImages.value = emptyList()
        generatedPdfFile.value = null
        compressSelectedUri.value = null
        compressedResult.value = null
        resizeSelectedUri.value = null
        resizedResult.value = null
        scanCapturedUri.value = null
        scanPreviewBitmap.value = null
        scanExportedFile.value = null
    }
}
