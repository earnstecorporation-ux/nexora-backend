package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexoraBackground
import com.example.ui.theme.NexoraCard
import com.example.ui.theme.NexoraCardElevated
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraGold
import com.example.ui.theme.NexoraMainText
import com.example.ui.theme.NexoraMutedText
import com.example.ui.theme.NexoraOutline
import com.example.ui.theme.NexoraSkyBlue
import com.example.ui.theme.NexoraSuccess
import com.example.ui.viewmodel.PaymentFlowState
import com.example.ui.viewmodel.PocketToolsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PremiumScreen(
    viewModel: PocketToolsViewModel,
    modifier: Modifier = Modifier
) {
    val isPremium by viewModel.isPremium.collectAsState()
    val paymentState by viewModel.paymentState.collectAsState()
    val verifiedEntitlement by viewModel.verifiedEntitlement.collectAsState()
    val pendingVerification by viewModel.pendingVerification.collectAsState()

    var showConfigDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraBackground)
            .testTag("premium_screen_scroll"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card (State-aware)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("premium_hero_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraCardElevated),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraOutline))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(if (isPremium) NexoraGold.copy(alpha = 0.18f) else NexoraElectricBlue.copy(alpha = 0.18f))
                            .border(1.dp, if (isPremium) NexoraGold.copy(alpha = 0.4f) else NexoraElectricBlue.copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPremium) Icons.Default.CheckCircle else Icons.Default.AutoAwesome,
                            contentDescription = "Lifetime Badge",
                            tint = if (isPremium) NexoraGold else NexoraSkyBlue,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (isPremium) "NEXORA Lifetime Premium Active" else "NEXORA Lifetime Premium",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = NexoraMainText,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isPremium) NexoraGold.copy(alpha = 0.15f)
                                else NexoraElectricBlue.copy(alpha = 0.15f)
                            )
                            .border(
                                1.dp,
                                if (isPremium) NexoraGold.copy(alpha = 0.35f)
                                else NexoraElectricBlue.copy(alpha = 0.35f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isPremium) "Lifetime Verified • Unlimited Access" else "₹49 • One-Time Payment",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isPremium) NexoraGold else NexoraSkyBlue,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isPremium) {
                            "Verified Order: ${verifiedEntitlement.orderId.ifEmpty { "LIFETIME_ENTITLED" }}\nUnlocked on ${formatTimestamp(verifiedEntitlement.verifiedAt)}"
                        } else {
                            "One-time payment of ₹49 only. No monthly or yearly renewals, no passwords, and no recurring commitments."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = NexoraMutedText,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    if (!isPremium) {
                        // Payment CTA Button
                        val isBusy = paymentState is PaymentFlowState.CreatingOrder ||
                                paymentState is PaymentFlowState.AwaitingCheckout ||
                                paymentState is PaymentFlowState.VerifyingSignature

                        Button(
                            onClick = { viewModel.initiateLifetimePurchase() },
                            enabled = !isBusy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("pay_premium_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NexoraElectricBlue,
                                contentColor = NexoraMainText,
                                disabledContainerColor = NexoraElectricBlue.copy(alpha = 0.4f)
                            )
                        ) {
                            if (isBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = NexoraMainText,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = when (paymentState) {
                                        is PaymentFlowState.CreatingOrder -> "Creating Order on Backend..."
                                        is PaymentFlowState.AwaitingCheckout -> "Opening Razorpay..."
                                        is PaymentFlowState.VerifyingSignature -> "Verifying Payment Signature..."
                                        else -> "Processing..."
                                    },
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Pay ₹49 with Razorpay",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    } else {
                        // Active status indicator + testing reset option
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = NexoraSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "All Document & Image Limits Removed",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = NexoraSuccess
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = { showResetDialog = true },
                            modifier = Modifier.testTag("reset_entitlement_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset Entitlement (Test Mode)")
                        }
                    }
                }
            }
        }

        // Payment State Status Alert (Errors, Cancellation, Verification Status)
        if (paymentState !is PaymentFlowState.Idle) {
            item {
                PaymentStatusCard(
                    state = paymentState,
                    onRetryCheckout = { viewModel.initiateLifetimePurchase() },
                    onRetryVerification = { viewModel.retryPendingVerification() },
                    onOpenConfig = { showConfigDialog = true },
                    onDismiss = { viewModel.resetPaymentFlowState() }
                )
            }
        }

        // Pending Verification Card (if any pending unverified payments exist)
        if (pendingVerification != null && !isPremium) {
            item {
                PendingVerificationCard(
                    pending = pendingVerification!!,
                    onVerifyClick = { viewModel.retryPendingVerification() }
                )
            }
        }

        // Plan Comparison Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tier_comparison_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraOutline))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Plan Comparison",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NexoraMainText
                    )

                    ComparisonRow(
                        feature = "Images to PDF Conversion",
                        freeText = "3 images / batch",
                        premiumText = "Unlimited batch"
                    )

                    ComparisonRow(
                        feature = "Image Compression",
                        freeText = "Local quality slider",
                        premiumText = "Max compression ratio"
                    )

                    ComparisonRow(
                        feature = "Image Dimension Scaling",
                        freeText = "Local aspect ratio resize",
                        premiumText = "High-precision export"
                    )

                    ComparisonRow(
                        feature = "Document Scanner Filters",
                        freeText = "High-contrast B&W filter",
                        premiumText = "HD scan export"
                    )

                    ComparisonRow(
                        feature = "Advertisements",
                        freeText = "Non-intrusive banner",
                        premiumText = "100% Ad-Free"
                    )

                    ComparisonRow(
                        feature = "Billing Frequency",
                        freeText = "Forever Free",
                        premiumText = "₹49 One-Time (Never renews)"
                    )
                }
            }
        }

        // Backend & Razorpay Setup Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("backend_config_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraCardElevated),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraOutline))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NexoraElectricBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Backend Security",
                            tint = NexoraSkyBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Order & Signature Backend",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = NexoraMainText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "URL: ${viewModel.paymentRepository.getEffectiveBackendUrl()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = NexoraMutedText,
                            maxLines = 1
                        )
                        val keyId = viewModel.paymentRepository.getEffectiveRazorpayKeyId()
                        val isLive = keyId.startsWith("rzp_live")
                        Text(
                            text = "Razorpay Key: ${keyId.take(12)}... (${if (isLive) "LIVE" else "TEST"} Mode)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isLive) NexoraGold else NexoraSkyBlue
                        )
                    }

                    IconButton(
                        onClick = { showConfigDialog = true },
                        modifier = Modifier.testTag("open_config_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Configure Backend",
                            tint = NexoraSkyBlue
                        )
                    }
                }
            }
        }

        // 100% On-Device Privacy Guarantee
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("privacy_guarantee_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraOutline))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NexoraSuccess.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Privacy Shield",
                            tint = NexoraSuccess,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "100% On-Device Utilities",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = NexoraMainText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Images to PDF, Image Compression, Image Resizing, and Document Scanning operate completely locally on your device. No mobile login, no passwords, no OTP, and zero cloud uploads.",
                            style = MaterialTheme.typography.bodySmall,
                            color = NexoraMutedText,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Ads & Monetization Strategy Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ads_strategy_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraOutline))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NexoraGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "AdMob Strategy",
                            tint = NexoraGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "Sustainable Monetization",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = NexoraMainText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Supported by unobtrusive banner ads on the free tier. The one-time ₹49 Premium removes all advertisements permanently.",
                            style = MaterialTheme.typography.bodySmall,
                            color = NexoraMutedText,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    // Config Backend Dialog
    if (showConfigDialog) {
        BackendConfigDialog(
            currentBackendUrl = viewModel.paymentRepository.getEffectiveBackendUrl(),
            currentKeyId = viewModel.paymentRepository.getEffectiveRazorpayKeyId(),
            viewModel = viewModel,
            onSave = { newUrl, newKey ->
                viewModel.setCustomBackendUrl(newUrl)
                if (newKey.isNotBlank()) viewModel.setCustomRazorpayKey(newKey)
                showConfigDialog = false
            },
            onDismiss = { showConfigDialog = false }
        )
    }

    // Reset Entitlement Confirmation Dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Entitlement?") },
            text = { Text("This will return the app to the Free Tier for testing payment verification.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetEntitlementForTesting()
                        showResetDialog = false
                    }
                ) {
                    Text("Reset to Free", color = NexoraError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PaymentStatusCard(
    state: PaymentFlowState,
    onRetryCheckout: () -> Unit,
    onRetryVerification: () -> Unit,
    onOpenConfig: () -> Unit,
    onDismiss: () -> Unit
) {
    val isError = state is PaymentFlowState.Error
    val isCancelled = state is PaymentFlowState.Cancelled
    val isSuccess = state is PaymentFlowState.VerifiedSuccess

    val containerColor = when {
        isSuccess -> NexoraSuccess.copy(alpha = 0.15f)
        isCancelled -> NexoraGold.copy(alpha = 0.15f)
        isError -> NexoraError.copy(alpha = 0.15f)
        else -> NexoraElectricBlue.copy(alpha = 0.15f)
    }

    val iconTint = when {
        isSuccess -> NexoraSuccess
        isCancelled -> NexoraGold
        isError -> NexoraError
        else -> NexoraSkyBlue
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("payment_status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(iconTint.copy(alpha = 0.4f)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = when {
                        isSuccess -> Icons.Default.CheckCircle
                        isCancelled -> Icons.Default.WarningAmber
                        isError -> Icons.Default.ErrorOutline
                        else -> Icons.Default.Info
                    },
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = when (state) {
                        is PaymentFlowState.CreatingOrder -> "Creating Order on Server"
                        is PaymentFlowState.AwaitingCheckout -> "Awaiting Checkout"
                        is PaymentFlowState.VerifyingSignature -> "Verifying Cryptographic Signature"
                        is PaymentFlowState.VerifiedSuccess -> "Payment Verified Successfully"
                        is PaymentFlowState.Cancelled -> "Payment Cancelled"
                        is PaymentFlowState.Error -> "Payment Server Notice"
                        PaymentFlowState.Idle -> ""
                    },
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = NexoraMainText
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            val message = when (state) {
                is PaymentFlowState.CreatingOrder -> "Connecting to payment backend to generate an order for ₹49..."
                is PaymentFlowState.AwaitingCheckout -> "Order ${state.orderId} created. Please complete payment in Razorpay."
                is PaymentFlowState.VerifyingSignature -> "Sending payment proof (Order: ${state.orderId}) to secure backend for HMAC SHA-256 signature verification..."
                is PaymentFlowState.VerifiedSuccess -> "Order ${state.orderId} verified by server! Lifetime Premium is now active."
                is PaymentFlowState.Cancelled -> state.message
                is PaymentFlowState.Error -> state.message
                PaymentFlowState.Idle -> ""
            }

            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = NexoraMutedText,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state is PaymentFlowState.Error) {
                    OutlinedButton(
                        onClick = onOpenConfig,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Configure URL")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                if (state is PaymentFlowState.Error && state.canRetryVerification) {
                    Button(
                        onClick = onRetryVerification,
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraElectricBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Retry Verification")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                } else if (state is PaymentFlowState.Cancelled || state is PaymentFlowState.Error) {
                    Button(
                        onClick = onRetryCheckout,
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraElectricBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Try Again")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                TextButton(onClick = onDismiss) {
                    Text("Dismiss", color = NexoraMainText)
                }
            }
        }
    }
}

@Composable
private fun PendingVerificationCard(
    pending: com.example.data.payment.repository.PendingVerification,
    onVerifyClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pending_verification_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NexoraGold.copy(alpha = 0.14f)),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(NexoraGold.copy(alpha = 0.4f)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = NexoraGold,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Pending Server Verification",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = NexoraMainText
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Payment recorded (Order: ${pending.orderId.take(16)}...). Server verification was pending due to network or backend connectivity.",
                style = MaterialTheme.typography.bodySmall,
                color = NexoraMutedText,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onVerifyClick,
                colors = ButtonDefaults.buttonColors(containerColor = NexoraGold, contentColor = NexoraBackground),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Verify Signature Now", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun BackendConfigDialog(
    currentBackendUrl: String,
    currentKeyId: String,
    viewModel: PocketToolsViewModel,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var urlText by remember { mutableStateOf(currentBackendUrl) }
    var keyText by remember { mutableStateOf(currentKeyId) }
    var testResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var isTesting by remember { mutableStateOf(false) }

    val trimmedUrl = urlText.trim()
    val isLikelySecret = trimmedUrl.startsWith("rzp_", ignoreCase = true) ||
            (!trimmedUrl.contains("://") && !trimmedUrl.contains(".") && trimmedUrl.length >= 16)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Backend & Payment Setup",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "NEXORA creates orders and verifies HMAC SHA-256 signatures on your backend. Deploy the Node server in /backend to Render, Railway, or Cloud Run, and enter the HTTPS URL below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = NexoraMutedText
                )

                OutlinedTextField(
                    value = urlText,
                    onValueChange = {
                        urlText = it
                        testResult = null
                    },
                    label = { Text("Backend HTTPS URL") },
                    placeholder = { Text("https://your-backend.onrender.com") },
                    singleLine = true,
                    isError = isLikelySecret,
                    supportingText = {
                        if (isLikelySecret) {
                            Text(
                                "⚠️ This looks like an API Key or Secret, not a URL! For security, your Razorpay Key Secret belongs exclusively on the backend. Please enter your backend HTTPS URL (e.g. https://your-backend.onrender.com).",
                                color = NexoraError
                            )
                        } else {
                            Text("Example: https://your-backend.onrender.com")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("backend_url_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexoraElectricBlue,
                        unfocusedBorderColor = NexoraOutline
                    )
                )

                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    label = { Text("Razorpay Key ID (Public Key)") },
                    placeholder = { Text("rzp_test_... or rzp_live_...") },
                    singleLine = true,
                    supportingText = {
                        Text("Only the public Key ID is stored in the app.")
                    },
                    modifier = Modifier.fillMaxWidth().testTag("razorpay_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexoraElectricBlue,
                        unfocusedBorderColor = NexoraOutline
                    )
                )

                // Test Connection Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            isTesting = true
                            testResult = null
                            viewModel.testBackendConnection(urlText) { success, msg ->
                                isTesting = false
                                testResult = Pair(success, msg)
                            }
                        },
                        enabled = !isTesting && urlText.isNotBlank() && !isLikelySecret,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Testing...")
                        } else {
                            Text("Test Connection")
                        }
                    }
                }

                testResult?.let { (success, msg) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (success) NexoraSuccess.copy(alpha = 0.15f) else NexoraError.copy(alpha = 0.15f))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = if (success) "✅ $msg" else "❌ $msg",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (success) NexoraSuccess else NexoraError
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(urlText, keyText) },
                enabled = !isLikelySecret && urlText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = NexoraElectricBlue)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun ComparisonRow(
    feature: String,
    freeText: String,
    premiumText: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = feature,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = NexoraMainText
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(NexoraSkyBlue)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Free: $freeText",
                    style = MaterialTheme.typography.labelSmall,
                    color = NexoraMutedText
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = NexoraGold,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = premiumText,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = NexoraGold
                )
            }
        }
    }
}

private fun formatTimestamp(timestamp: Long): String {
    if (timestamp <= 0) return "Active"
    return try {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        sdf.format(Date(timestamp))
    } catch (e: Exception) {
        "Active"
    }
}
